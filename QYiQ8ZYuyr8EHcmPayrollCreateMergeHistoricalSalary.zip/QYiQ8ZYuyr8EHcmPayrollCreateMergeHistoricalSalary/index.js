
/**
 * Nome da primitiva : createMergeHistoricalSalary
 * Nome do dominio : hcm
 * Nome do serviço : payroll
 * Nome do tenant : trn07162531
 **/
 
const axios = require('axios');

exports.handler = async (event) => {
  //Define variável para recebermos o corpo da requisição
  let body;

  body = parseBody(event);
  
  let tokenSeniorX = event.headers['X-Senior-Token'];

  const instance = axios.create({
    baseURL: 'https://platform-homologx.senior.com.br/t/senior.com.br/bridge/1.0/rest/',
    headers: {
      'Authorization': tokenSeniorX
    }
  });
  
  //valida o motivo de alteração de salario
  if(body.movimentationReason){
    //como não encontrei o campo de motivo salarial na alteração, estou supondo que o ID do motivo admissão seja sempre esse informado
    //logo se a validação detectar que o ID é esse, pré-supoem que foi selecionado o motivo 1 - Admissão
    if(body.movimentationReason.id === 'B42CA54A15674C26A2DD9E11657F4E29'){
      return sendRes(400,'Para alterações salariais é necessário utilizar motivos de alteração diferentes de 1 - Admissão');
    }
  }
  
  //valida a data de alteração salarial, não permite datas retroativas
  let dDatAtu = new Date().setHours(0,0,0,0);//data atual em milessegundos
  let dDatAlt = Date.parse(body.dateWhen);//converte a data de texto para milessegundos
  if (dDatAlt < dDatAtu) {
    return sendRes(400,'A data de alteração salarial não pode ser retroativa');  
  }
  
  //valida a situação do colaborador é demitido
  if(body.employee) {                                                                                        
    let employee = await instance.get(`/hcm/payroll/entities/employee/${body.employee.id}`);
    
    let teste = body.employee;
  }
  
  return sendRes(200, JSON.parse(event.body));
};



const parseBody = (event) => {
  //verifica se o event.body já contem uma string, ou seja, já contém o formato JSON, não precisa fazer a conversão
  return typeof event.body === 'string' ?  JSON.parse(event.body) : event.body || {};
};

const sendRes = (status, body) => {
    var response = {
      statusCode: status,
      headers: {
        "Content-Type": "application/json"
      },
      body: typeof body === 'string' ? body : JSON.stringify(body) 
    };
    
    console.log(body);
    
    return response;
};
