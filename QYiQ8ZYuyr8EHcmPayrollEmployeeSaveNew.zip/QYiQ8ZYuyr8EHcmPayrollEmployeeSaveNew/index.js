
/**
 * Nome da primitiva : employeeSave
 * Nome do dominio : hcm
 * Nome do serviço : payroll
 * Nome do tenant : trn07162531
 **/
 
const axios = require('axios');

exports.handler = async (event) => {
  //Define variável para recebermos o corpo da requisição
  let body;

  body = parseBody(event);
  
  let tokenSeniorX = event.headers['X-Senior-Token'];

  const instance = axios.create({
    baseURL: 'https://platform-homologx.senior.com.br/t/senior.com.br/bridge/1.0/rest/',
    headers: {
      'Authorization': tokenSeniorX
    }
  });
  
  //trabalho SDK
  let pastaContrato = body.sheetContract;
  let pastaInicial = body.sheetInitial;
  
  //obriga a preencher a matrícula do colaborador
  if(!pastaContrato.registernumber){
    return sendRes(400, 'É obrigatório informar a matrícula do colaborador!');
  } 
   
  //Não deve permitir a realização de Admissão com o campo Indicativo de Admissão com o valor diferente de Normal.
  if (pastaContrato.admissionOriginType.key !== "NORMAL"){
    return sendRes(400, 'Não é permitido realizar a Admissão com o campo "Indicativo de Admissão" com o valor diferente de Normal!'); 
  }
  
  //Valida apenas quando for uma alteração de registro. 
  if(pastaInicial.employee) {                                                                                        
    let employee = await instance.get(`/hcm/payroll/entities/employee/${pastaInicial.employee.tableId}`);
   
    //nos registros gravados o sistema salva os mesmos em três campos, primeiro nome, segundo nome e sobrenome
    let nomePri =  employee.data.person.firstname;
    let nomeMei = employee.data.person.middlename; 
    let sobrenome = employee.data.person.lastname; 
    let nomeCompleto = nomePri;

    if(nomeMei){
      nomeCompleto = nomeCompleto + " " + nomeMei; 
    }
    if(sobrenome){
      nomeCompleto = nomeCompleto + " " + sobrenome; 
    }

    if(nomeCompleto !== pastaInicial.employee.name){
      return sendRes(400,'Não é permitido alterar o nome do colaborador!'); 
    }
  }

  
  //verificação de Escalas para o tipo de contrato do empregado 
  if((pastaInicial.contractType.key === 'Employee') && (body.sheetWorkSchedule.workshift.tableId)){
    let codEscala = await instance.get(`/hcm/payroll/entities/workshift/${body.sheetWorkSchedule.workshift.tableId}`);
    
    if(codEscala.data.code){
      if(codEscala.data.code < 11) {
        return sendRes(400,'Para o tipo de contrato 1 - Empregado, somente é possível utilizar as escalas de código 1 a 10!');
      }
    }else{
      return sendRes(400,'É obrigatório informar a escala de trabalho do colaborador');
    }
    
   if (codEscala.data.workshiftType !== "Permanent"){
      return sendRes(400,'Você deve informar uma escala do Tipo Permanente!');  
    }
  }
  
  //validações realizadas durante o treinamento
  //Valida tamanho do apelido
  if(body.sheetPersona.nickname) {
    if(body.sheetPersona.nickname.length > 10) {
      return sendRes(400,'O apelido deve ter no máximo 10 caracteres!');
    }
  } else {
    return sendRes(400,'O apelido deve ser informado!');
  }

  //Valida se a foto do colaborador está presente
  if(!body.sheetPersona.attachment){
    return sendRes(400,'A foto do colaborador deve ser informada!');
  } 

  /* Não permite alteração de CPF */
  if(body.sheetInitial.employee) {
      let employee = await instance.get(`/hcm/payroll/entities/employee/${body.sheetInitial.employee.tableId}`);

      if(employee.data.person.cpf !== body.sheetDocument.cpfNumber){
        return sendRes(400,'Não é permitido alterar o CPF do Colaborador!'); 
      }
  }
  
  /*Valida Campo customizado em conjunto com campo nativo*/
  if((body.sheetContract.customFieldsEmployee) && (body.sheetComplement.issueDotCard)) {
    let customFields = body.sheetContract.customFieldsEmployee;
    let issueDotCard = body.sheetComplement.issueDotCard;
    
    //Percorre o array de campos customizados
    for(let customField of customFields) {
      if(customField.field === 'USU_CarCon') {
        if((customField.value === 'S') && (issueDotCard.key === 'Yes')) {
          return sendRes(400,'Colaboradores com Cargo de confiança não devem emitir cartão Ponto!');
        }
      }
    }
  }
  
  //Dica, cuidar com o tipo de dado no momento da comparação
  //verifica quando o colaborador for deficiente, deve ter também a opção de preenche cota marcado com Sim.
  if((body.sheetPersona.isDisability) && (!body.sheetPersona.isOccupantQuota)) {
      return sendRes(400,'Quando o colaborador for deficiente, o campo Preenche cota deve ser informado com Sim!');
  }
  
  
  return sendRes(200, JSON.parse(event.body));
};

const parseBody = (event) => {
  //verifica se o event.body já contem uma string, ou seja, já contém o formato JSON, não precisa fazer a conversão
  return typeof event.body === 'string' ?  JSON.parse(event.body) : event.body || {};
};

const sendRes = (status, body) => {
    var response = {
      statusCode: status,
      headers: {
        "Content-Type": "application/json"
      },
      body: typeof body === 'string' ? body : JSON.stringify(body) 
    };
    
    console.log(body);
    
    return response;
};